export default {
  './todoInput': './src/remote/todoInput',
}
