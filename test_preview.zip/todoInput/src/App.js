import React from 'react'
import TodoInput from './remote/todoInput'

export default function App() {
  return <TodoInput />
}
