# test_preview

dckr_pat_RPjLNY3u0YU2S3j1EkPRNKCB9cI

zip -r test_preview.zip . -x '**/node_modules/*' -x '.env*' -x "._bb_/*"