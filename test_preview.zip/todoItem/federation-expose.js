export default {
  './todoItem': './src/remote/todoItem',
}
